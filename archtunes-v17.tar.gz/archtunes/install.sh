#!/usr/bin/env bash
# Install ArchTunes into ~/Applications/ArchTunes + app launcher integration.
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/Applications/ArchTunes"
ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"
DESKTOP_DIR="$HOME/.local/share/applications"

echo "==> Installing system dependencies (needs sudo)..."
sudo pacman -S --needed python-gobject python-cairo gtk4 libadwaita \
    gstreamer gst-plugins-base gst-plugins-good gst-plugins-bad gst-plugins-ugly

echo "==> Cleaning up any previous install..."
rm -rf "$INSTALL_DIR"

echo "==> Copying the app into $INSTALL_DIR ..."
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR"/main.py "$SCRIPT_DIR"/archtunes "$INSTALL_DIR"/
find "$INSTALL_DIR" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true

echo "==> Installing the icon..."
mkdir -p "$ICON_DIR"
cp "$SCRIPT_DIR/archtunes.svg" "$ICON_DIR/archtunes.svg"

echo "==> Creating the app launcher entry..."
mkdir -p "$DESKTOP_DIR"
printf '%s\n' \
  '[Desktop Entry]' \
  'Type=Application' \
  'Name=ArchTunes' \
  'Comment=Local music player' \
  "Exec=/usr/bin/python3 $INSTALL_DIR/main.py" \
  'Icon=archtunes' \
  'Terminal=false' \
  'Categories=Audio;Music;Player;AudioVideo;' \
  > "$DESKTOP_DIR/archtunes.desktop"

command -v update-desktop-database &> /dev/null && update-desktop-database "$DESKTOP_DIR" || true
command -v gtk-update-icon-cache &> /dev/null && gtk-update-icon-cache "$HOME/.local/share/icons/hicolor" || true

echo ""
echo "=================================================================="
echo " Done! ArchTunes is installed in $INSTALL_DIR"
echo " Search for 'ArchTunes' in your app launcher (Super key), or run:"
echo "      /usr/bin/python3 $INSTALL_DIR/main.py"
echo "=================================================================="
