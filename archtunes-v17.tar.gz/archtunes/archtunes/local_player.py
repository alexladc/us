"""Local file playback backend, using a GStreamer playbin pipeline."""
import re

import gi

gi.require_version("Gst", "1.0")
from gi.repository import Gst, GLib  # noqa: E402

Gst.init(None)

SPECTRUM_BANDS = 48
SPECTRUM_THRESHOLD_DB = -80

# On some PyGObject/GStreamer builds, GstStructure.get_value() cannot marshal
# a GST_TYPE_LIST field (raises "TypeError: unknown type GstValueList").
# As a fallback, we parse the magnitudes out of the structure's own string
# representation, e.g.: "...magnitude=(float){ -63.2, -60.1, ... };..."
_MAGNITUDE_RE = re.compile(r"magnitude=\(float\)\{([^}]*)\}")


class LocalPlayer:
    """Thin wrapper around playbin for mp3/flac/ogg/wav/etc. playback,
    with a live audio spectrum feed for visualizers."""

    def __init__(self, on_eos=None, on_error=None, on_state_changed=None):
        self.playbin = Gst.ElementFactory.make("playbin", "player")
        if self.playbin is None:
            raise RuntimeError(
                "Could not create the 'playbin' element. Check that "
                "gstreamer + gst-plugins-base/good/bad/ugly are installed."
            )

        # spectrum analyzer inserted into the audio path via playbin's
        # 'audio-filter' property - it passes audio through unchanged while
        # posting magnitude-per-band messages on the bus at a fixed interval.
        self._spectrum = Gst.ElementFactory.make("spectrum", "spectrum")
        if self._spectrum is not None:
            self._spectrum.set_property("bands", SPECTRUM_BANDS)
            self._spectrum.set_property("threshold", SPECTRUM_THRESHOLD_DB)
            self._spectrum.set_property("post-messages", True)
            self._spectrum.set_property("multi-channel", False)
            self._spectrum.set_property("interval", 50 * Gst.MSECOND)
            self.playbin.set_property("audio-filter", self._spectrum)

        self._on_eos = on_eos
        self._on_error = on_error
        self._on_state_changed = on_state_changed
        self._last_magnitudes = [SPECTRUM_THRESHOLD_DB] * SPECTRUM_BANDS

        bus = self.playbin.get_bus()
        bus.add_signal_watch()
        bus.connect("message::eos", self._handle_eos)
        bus.connect("message::error", self._handle_error)
        bus.connect("message::state-changed", self._handle_state_changed)
        bus.connect("message::element", self._handle_element_message)

        self.current_uri = None

    # --- playback control -------------------------------------------------
    def load(self, filepath: str):
        self.stop()
        uri = filepath if filepath.startswith("file://") else Gst.filename_to_uri(filepath)
        self.current_uri = uri
        self.playbin.set_property("uri", uri)

    def play(self):
        self.playbin.set_state(Gst.State.PLAYING)

    def pause(self):
        self.playbin.set_state(Gst.State.PAUSED)

    def stop(self):
        self.playbin.set_state(Gst.State.NULL)
        self._last_magnitudes = [SPECTRUM_THRESHOLD_DB] * SPECTRUM_BANDS

    def set_volume(self, value: float):
        """value between 0.0 and 1.0"""
        self.playbin.set_property("volume", max(0.0, min(1.0, value)))

    def get_volume(self) -> float:
        return self.playbin.get_property("volume")

    def seek(self, position_seconds: float):
        self.playbin.seek_simple(
            Gst.Format.TIME,
            Gst.SeekFlags.FLUSH,
            int(position_seconds * Gst.SECOND),
        )

    def get_position(self):
        """Returns the current position in seconds, or None if unavailable."""
        ok, pos = self.playbin.query_position(Gst.Format.TIME)
        if not ok:
            return None
        return pos / Gst.SECOND

    def get_duration(self):
        ok, dur = self.playbin.query_duration(Gst.Format.TIME)
        if not ok:
            return None
        return dur / Gst.SECOND

    def is_playing(self) -> bool:
        _, state, _ = self.playbin.get_state(0)
        return state == Gst.State.PLAYING

    def get_spectrum(self):
        """Returns the most recent list of per-band magnitudes, in dB
        (values roughly between the configured threshold and 0)."""
        return self._last_magnitudes

    # --- bus callbacks -------------------------------------------------
    def _handle_eos(self, bus, message):
        self.stop()
        if self._on_eos:
            self._on_eos()

    def _handle_error(self, bus, message):
        err, debug = message.parse_error()
        self.stop()
        if self._on_error:
            self._on_error(err, debug)

    def _handle_state_changed(self, bus, message):
        if message.src != self.playbin:
            return
        old, new, pending = message.parse_state_changed()
        if self._on_state_changed:
            self._on_state_changed(old, new, pending)

    def _handle_element_message(self, bus, message):
        structure = message.get_structure()
        if structure is None or structure.get_name() != "spectrum":
            return
        magnitudes = None
        try:
            magnitudes = structure.get_value("magnitude")
        except TypeError:
            # fallback: parse the values out of the structure's string form
            match = _MAGNITUDE_RE.search(structure.to_string())
            if match:
                try:
                    magnitudes = [
                        float(x.strip()) for x in match.group(1).split(",") if x.strip()
                    ]
                except ValueError:
                    magnitudes = None
        if magnitudes:
            self._last_magnitudes = list(magnitudes)
