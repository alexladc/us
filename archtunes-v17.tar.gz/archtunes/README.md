# ArchTunes

A GTK4 + libadwaita local music player for Arch Linux, with a live
audio-reactive visualizer, dark theme, and playlist persistence.

## Install

```bash
chmod +x install.sh
./install.sh
```

The script:
1. installs required system dependencies (pacman)
2. copies the app into `~/Applications/ArchTunes`
3. installs the icon into `~/.local/share/icons/hicolor/scalable/apps`
4. creates `~/.local/share/applications/archtunes.desktop`, so it shows up
   in your app launcher (GNOME Activities, KDE launcher, rofi/wofi, etc.)

After installing, just search for **"ArchTunes"** in your launcher.

## Run manually (without the launcher)

```bash
python3 ~/Applications/ArchTunes/main.py
```

## Features

- Dark, modern UI with a sidebar playlist
- Add local audio files (mp3, flac, ogg, wav, m4a)
- Play / pause / next / previous, with the currently playing track
  highlighted in the list
- Seek bar (click or drag to jump anywhere in the track)
- Volume control
- Live audio visualizer bars, driven by a real-time GStreamer spectrum
  analysis of the audio (not a fake animation) - reacts to the actual music
- Space bar toggles play/pause
- Playlist is saved automatically and reloaded next time you open the app

## Project structure (source, before install)

```
archtunes/
├── main.py                  # entry point
├── archtunes/
│   ├── window.py             # main GTK4 window + UI
│   └── local_player.py       # playback backend (GStreamer/playbin + spectrum)
├── archtunes.svg             # app icon
├── install.sh                # install script + launcher integration
└── README.md
```

## Uninstall

```bash
rm -rf ~/Applications/ArchTunes
rm ~/.local/share/applications/archtunes.desktop
rm ~/.local/share/icons/hicolor/scalable/apps/archtunes.svg
update-desktop-database ~/.local/share/applications 2>/dev/null || true
```

## Ideas for further extension

- read embedded metadata (title/artist/album) from audio file tags
- MPRIS integration (control from media keys / other apps)
- support adding entire folders (recursive scan), not just individual files
- multiple playlists
