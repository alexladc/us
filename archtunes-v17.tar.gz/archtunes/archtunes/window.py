"""ArchTunes main window - local music player, dark modern UI + radial audio visualizer + themes."""
import json
import math
import os
import random

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk, GLib, Gdk  # noqa: E402

from archtunes.local_player import LocalPlayer  # noqa: E402

PLAYLIST_FILE = os.path.expanduser("~/.local/share/archtunes/playlist.json")
SETTINGS_FILE = os.path.expanduser("~/.local/share/archtunes/settings.json")

VISUALIZER_BARS = 48
VISUALIZER_SIZE = 420
VISUALIZER_INNER_RADIUS = 95
VISUALIZER_MAX_LENGTH = 70
VISUALIZER_MIN_LENGTH = 5
VISUALIZER_DECAY = 0.82
SPECTRUM_THRESHOLD_DB = -80  # must match local_player.SPECTRUM_THRESHOLD_DB

THEMES = {
    "purple":  {"name": "Purple",      "accent": "#7c5cff", "hover": "#8f72ff"},
    "blue":    {"name": "Ocean Blue",  "accent": "#3b82f6", "hover": "#5b9bfa"},
    "green":   {"name": "Emerald",     "accent": "#22c55e", "hover": "#3ddc74"},
    "red":     {"name": "Crimson",     "accent": "#ef4444", "hover": "#f56565"},
    "orange":  {"name": "Sunset",      "accent": "#f97316", "hover": "#fb923c"},
    "pink":    {"name": "Rose",        "accent": "#ec4899", "hover": "#f472b6"},
    "mono":    {"name": "Monochrome",  "accent": "#e5e5e5", "hover": "#ffffff"},
}
DEFAULT_THEME = "purple"

CSS_TEMPLATE = """
window {
    background-color: #121212;
}
.at-sidebar {
    background-color: #181818;
    border-right: 1px solid #262626;
}
.at-sidebar-title {
    font-weight: 800;
    font-size: 13px;
    letter-spacing: 1.5px;
    color: #8a8a8a;
    margin: 14px 16px 6px 16px;
}
.at-sidebar row {
    padding: 8px 14px;
    border-radius: 8px;
    margin: 1px 8px;
}
.at-sidebar row:selected {
    background-color: #2a2a2a;
}
.at-sidebar row label {
    color: #d8d8d8;
    font-size: 13px;
}
.at-add-btn {
    margin: 10px 12px 4px 12px;
    background-color: #232323;
    color: #e8e8e8;
    border-radius: 8px;
}
.at-add-btn:hover {
    background-color: #2d2d2d;
}
.at-content {
    background-color: #121212;
}
.at-track-title {
    font-size: 19px;
    font-weight: 800;
    color: #ffffff;
}
.at-track-subtitle {
    font-size: 12px;
    color: #8a8a8a;
}
.at-time-label {
    font-size: 11px;
    color: #8a8a8a;
    min-width: 36px;
}
scale.at-progress trough {
    min-height: 4px;
    border-radius: 4px;
    background-color: #2a2a2a;
}
scale.at-progress highlight {
    min-height: 4px;
    border-radius: 4px;
    background-color: __ACCENT__;
}
scale.at-progress slider {
    min-width: 10px;
    min-height: 10px;
    border-radius: 999px;
    background-color: #ffffff;
}
.at-circle-btn {
    border-radius: 999px;
    min-width: 46px;
    min-height: 46px;
    background-color: #1e1e1e;
    color: #e8e8e8;
}
.at-circle-btn:hover {
    background-color: #292929;
}
.at-play-btn {
    border-radius: 999px;
    min-width: 68px;
    min-height: 68px;
    background-color: __ACCENT__;
    color: #ffffff;
}
.at-play-btn:hover {
    background-color: __ACCENT_HOVER__;
}
.at-theme-btn {
    border-radius: 999px;
    min-width: 40px;
    min-height: 40px;
    background-color: #1e1e1e;
    color: #e8e8e8;
    font-size: 16px;
}
.at-theme-btn:hover {
    background-color: #292929;
}
scale.at-volume trough {
    min-height: 3px;
    border-radius: 3px;
    background-color: #2a2a2a;
}
scale.at-volume highlight {
    min-height: 3px;
    border-radius: 3px;
    background-color: #6a6a6a;
}
scale.at-volume slider {
    min-width: 9px;
    min-height: 9px;
    border-radius: 999px;
    background-color: #d8d8d8;
}
"""


def _hex_to_rgb_floats(hex_color):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i + 2], 16) / 255 for i in (0, 2, 4))


class ArchTunesWindow(Adw.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        self.set_title("ArchTunes")
        self.set_default_size(920, 740)

        self.local_player = LocalPlayer(
            on_eos=self._on_track_finished,
            on_error=self._on_playback_error,
        )
        self._playlist = []
        self._current_index = -1
        self._programmatic_update = False
        self._pending_seek_id = None
        self._pending_seek_value = 0
        self._visual_levels = [0.0] * VISUALIZER_BARS
        self._bar_gain = [random.uniform(0.7, 1.35) for _ in range(VISUALIZER_BARS)]
        self._energy_avg = 0.0
        self._css_provider = None

        theme_key = self._load_settings()
        self._current_theme_key = theme_key
        self._accent_rgba = _hex_to_rgb_floats(THEMES[theme_key]["accent"])
        self._apply_css(theme_key)

        self._build_ui()
        self._setup_keyboard_shortcuts()
        self._load_playlist()

        GLib.timeout_add(500, self._update_progress)
        GLib.timeout_add(33, self._update_visualizer)

    # --- styling / themes -----------------------------------------------------
    def _apply_css(self, theme_key):
        theme = THEMES.get(theme_key, THEMES[DEFAULT_THEME])
        css = (
            CSS_TEMPLATE
            .replace("__ACCENT_HOVER__", theme["hover"])
            .replace("__ACCENT__", theme["accent"])
        ).encode()

        display = Gdk.Display.get_default()
        if self._css_provider is not None:
            Gtk.StyleContext.remove_provider_for_display(display, self._css_provider)

        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_display(
            display, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )
        self._css_provider = provider

    def _set_theme(self, theme_key):
        if theme_key not in THEMES:
            return
        self._current_theme_key = theme_key
        self._accent_rgba = _hex_to_rgb_floats(THEMES[theme_key]["accent"])
        self._apply_css(theme_key)
        self._save_settings()
        if hasattr(self, "visualizer_area"):
            self.visualizer_area.queue_draw()

    def _on_theme_selected(self, button, theme_key, popover):
        self._set_theme(theme_key)
        popover.popdown()

    # --- settings persistence -------------------------------------------------
    def _load_settings(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r") as f:
                    data = json.load(f)
                key = data.get("theme", DEFAULT_THEME)
                if key in THEMES:
                    return key
            except (OSError, json.JSONDecodeError):
                pass
        return DEFAULT_THEME

    def _save_settings(self):
        try:
            os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
            with open(SETTINGS_FILE, "w") as f:
                json.dump({"theme": self._current_theme_key}, f)
        except OSError:
            pass

    # --- keyboard shortcuts -----------------------------------------------------
    def _setup_keyboard_shortcuts(self):
        key_controller = Gtk.EventControllerKey()
        key_controller.connect("key-pressed", self._on_key_pressed)
        self.add_controller(key_controller)

    def _on_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Gdk.KEY_space:
            self._on_play_pause_clicked(None)
            return True
        return False

    # --- UI construction ------------------------------------------------------
    def _build_ui(self):
        root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)

        # === sidebar (playlist) ===
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        sidebar.set_size_request(220, -1)
        sidebar.add_css_class("at-sidebar")

        sidebar_title = Gtk.Label(label="PLAYLIST", halign=Gtk.Align.START)
        sidebar_title.add_css_class("at-sidebar-title")
        sidebar.append(sidebar_title)

        add_files_btn = Gtk.Button(label="+  Add files")
        add_files_btn.add_css_class("at-add-btn")
        add_files_btn.connect("clicked", self._on_add_files_clicked)
        sidebar.append(add_files_btn)

        self.list_box = Gtk.ListBox()
        self.list_box.add_css_class("at-sidebar")
        self.list_box.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.list_box.connect("row-activated", self._on_row_activated)
        list_scrolled = Gtk.ScrolledWindow(vexpand=True)
        list_scrolled.set_child(self.list_box)
        sidebar.append(list_scrolled)

        root.append(sidebar)

        # === main content ===
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True, vexpand=True)
        content.add_css_class("at-content")

        # top row: progress bar + theme menu button
        progress_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10,
                                margin_top=22, margin_start=28, margin_end=28)
        self.elapsed_label = Gtk.Label(label="0:00", halign=Gtk.Align.END)
        self.elapsed_label.add_css_class("at-time-label")

        self.progress_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        self.progress_scale.set_hexpand(True)
        self.progress_scale.set_draw_value(False)
        self.progress_scale.add_css_class("at-progress")
        self.progress_scale.connect("change-value", self._on_seek_change_value)

        self.duration_label = Gtk.Label(label="0:00", halign=Gtk.Align.START)
        self.duration_label.add_css_class("at-time-label")

        theme_menu_button = self._build_theme_menu_button()

        progress_row.append(self.elapsed_label)
        progress_row.append(self.progress_scale)
        progress_row.append(self.duration_label)
        progress_row.append(theme_menu_button)
        content.append(progress_row)

        # center area: radial visualizer with the track name in the middle,
        # then the playback buttons below
        center_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18,
                              valign=Gtk.Align.CENTER, vexpand=True,
                              halign=Gtk.Align.CENTER)

        overlay = Gtk.Overlay()
        overlay.set_size_request(VISUALIZER_SIZE, VISUALIZER_SIZE)

        self.visualizer_area = Gtk.DrawingArea()
        self.visualizer_area.set_content_width(VISUALIZER_SIZE)
        self.visualizer_area.set_content_height(VISUALIZER_SIZE)
        self.visualizer_area.set_draw_func(self._on_visualizer_draw)
        overlay.set_child(self.visualizer_area)

        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4,
                            halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.now_playing_label = Gtk.Label(label="Nothing playing")
        self.now_playing_label.add_css_class("at-track-title")
        self.now_playing_label.set_justify(Gtk.Justification.CENTER)
        self.now_playing_label.set_wrap(True)
        self.now_playing_label.set_max_width_chars(16)

        self.subtitle_label = Gtk.Label(label="Select a track")
        self.subtitle_label.add_css_class("at-track-subtitle")

        text_box.append(self.now_playing_label)
        text_box.append(self.subtitle_label)
        overlay.add_overlay(text_box)

        center_box.append(overlay)

        buttons_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=22,
                               halign=Gtk.Align.CENTER)

        self.prev_btn = Gtk.Button(icon_name="media-skip-backward-symbolic")
        self.prev_btn.add_css_class("at-circle-btn")
        self.prev_btn.connect("clicked", self._on_prev_clicked)

        self.play_btn = Gtk.Button(icon_name="media-playback-start-symbolic")
        self.play_btn.add_css_class("at-play-btn")
        self.play_btn.connect("clicked", self._on_play_pause_clicked)

        self.next_btn = Gtk.Button(icon_name="media-skip-forward-symbolic")
        self.next_btn.add_css_class("at-circle-btn")
        self.next_btn.connect("clicked", self._on_next_clicked)

        buttons_row.append(self.prev_btn)
        buttons_row.append(self.play_btn)
        buttons_row.append(self.next_btn)

        center_box.append(buttons_row)
        content.append(center_box)

        # volume, bottom-right
        volume_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8,
                              halign=Gtk.Align.END, margin_end=28, margin_bottom=22)
        volume_icon = Gtk.Image.new_from_icon_name("audio-volume-high-symbolic")
        self.volume_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        self.volume_scale.set_value(80)
        self.volume_scale.set_size_request(130, -1)
        self.volume_scale.set_draw_value(False)
        self.volume_scale.add_css_class("at-volume")
        self.volume_scale.connect("value-changed", self._on_volume_changed)
        volume_row.append(volume_icon)
        volume_row.append(self.volume_scale)
        content.append(volume_row)

        root.append(content)

        self.set_content(root)
        self.local_player.set_volume(0.8)

    # --- theme menu -----------------------------------------------------------
    def _build_theme_menu_button(self):
        menu_button = Gtk.MenuButton(label="\U0001F3A8")  # palette emoji
        menu_button.add_css_class("at-theme-btn")
        menu_button.set_tooltip_text("Change color theme")

        popover = Gtk.Popover()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2,
                       margin_top=8, margin_bottom=8, margin_start=8, margin_end=8)

        for key, theme in THEMES.items():
            row_btn = Gtk.Button()
            row_btn.set_has_frame(False)
            label = Gtk.Label(xalign=0)
            label.set_markup(
                f"<span foreground='{theme['accent']}'>\u25cf</span>  {theme['name']}"
            )
            label.set_halign(Gtk.Align.START)
            row_btn.set_child(label)
            row_btn.connect("clicked", self._on_theme_selected, key, popover)
            box.append(row_btn)

        popover.set_child(box)
        menu_button.set_popover(popover)
        return menu_button

    # --- local library ----------------------------------------------------
    def _on_add_files_clicked(self, button):
        dialog = Gtk.FileChooserNative.new(
            "Select audio files", self, Gtk.FileChooserAction.OPEN, "_Open", "_Cancel"
        )
        dialog.set_select_multiple(True)
        filt = Gtk.FileFilter()
        filt.set_name("Audio files")
        for pattern in ("*.mp3", "*.flac", "*.ogg", "*.wav", "*.m4a"):
            filt.add_pattern(pattern)
        dialog.add_filter(filt)
        dialog.connect("response", self._on_file_dialog_response)
        dialog.show()

    def _on_file_dialog_response(self, dialog, response):
        if response == Gtk.ResponseType.ACCEPT:
            files = dialog.get_files()
            for i in range(files.get_n_items()):
                gfile = files.get_item(i)
                path = gfile.get_path()
                if path:
                    self._add_track_row(path)
            self._save_playlist()
        dialog.destroy()

    def _add_track_row(self, path):
        self._playlist.append(path)
        row = Gtk.ListBoxRow()
        row.set_child(Gtk.Label(label=path.split("/")[-1], halign=Gtk.Align.START,
                                 ellipsize=3))
        self.list_box.append(row)

    # --- playlist persistence -------------------------------------------------
    def _save_playlist(self):
        try:
            os.makedirs(os.path.dirname(PLAYLIST_FILE), exist_ok=True)
            with open(PLAYLIST_FILE, "w") as f:
                json.dump(self._playlist, f)
        except OSError:
            pass

    def _load_playlist(self):
        if not os.path.exists(PLAYLIST_FILE):
            return
        try:
            with open(PLAYLIST_FILE, "r") as f:
                saved = json.load(f)
        except (OSError, json.JSONDecodeError):
            return
        for path in saved:
            if os.path.isfile(path):
                self._add_track_row(path)
        if len(saved) != len(self._playlist):
            self._save_playlist()

    def _on_row_activated(self, list_box, row):
        self._current_index = row.get_index()
        self._play_index(self._current_index)

    def _play_index(self, index):
        if index < 0 or index >= len(self._playlist):
            return
        path = self._playlist[index]
        filename = path.split("/")[-1]
        self.local_player.load(path)
        self.local_player.play()
        self.now_playing_label.set_label(filename)
        self.subtitle_label.set_label("Now playing")
        self.play_btn.set_icon_name("media-playback-pause-symbolic")
        self._highlight_current_row()

    def _on_track_finished(self):
        GLib.idle_add(self._advance_track)

    def _advance_track(self):
        if self._current_index + 1 < len(self._playlist):
            self._current_index += 1
            self._play_index(self._current_index)
        else:
            self.play_btn.set_icon_name("media-playback-start-symbolic")
            self.subtitle_label.set_label("Playback finished")
        return False

    def _on_playback_error(self, err, debug):
        self.now_playing_label.set_label("Playback error")
        self.subtitle_label.set_label(str(err))

    # --- progress bar / seek --------------------------------------------
    def _on_seek_change_value(self, scale, scroll_type, value):
        if self._programmatic_update:
            return False
        value = max(0, min(100, value))
        self._pending_seek_value = value
        if self._pending_seek_id is not None:
            GLib.source_remove(self._pending_seek_id)
        self._pending_seek_id = GLib.timeout_add(150, self._perform_pending_seek)
        return False

    def _perform_pending_seek(self):
        duration = self.local_player.get_duration()
        if duration:
            self.local_player.seek(self._pending_seek_value / 100.0 * duration)
        self._pending_seek_id = None
        return False

    def _update_progress(self):
        if self._pending_seek_id is not None:
            return True
        position = self.local_player.get_position()
        duration = self.local_player.get_duration()
        if position is not None and duration:
            self._programmatic_update = True
            self.progress_scale.set_value((position / duration) * 100)
            self._programmatic_update = False
            self.elapsed_label.set_label(self._format_time(position))
            self.duration_label.set_label(self._format_time(duration))
        return True

    @staticmethod
    def _format_time(seconds):
        seconds = int(seconds)
        return f"{seconds // 60}:{seconds % 60:02d}"

    # --- radial audio visualizer --------------------------------------------------
    def _update_visualizer(self):
        self.visualizer_area.queue_draw()
        return True

    def _on_visualizer_draw(self, area, cr, width, height):
        cx, cy = width / 2, height / 2
        is_playing = self.local_player.is_playing()
        magnitudes = self.local_player.get_spectrum() if is_playing else None

        global_boost = 0.0
        if magnitudes:
            bass_band_count = max(1, len(magnitudes) // 6)
            bass_levels = []
            for db in magnitudes[:bass_band_count]:
                lvl = (db - SPECTRUM_THRESHOLD_DB) / (0 - SPECTRUM_THRESHOLD_DB)
                bass_levels.append(max(0.0, min(1.0, lvl)))
            current_energy = sum(bass_levels) / len(bass_levels) if bass_levels else 0.0
            self._energy_avg = self._energy_avg * 0.90 + current_energy * 0.10
            spike = current_energy - self._energy_avg * 1.05
            if spike > 0:
                global_boost = min(1.0, spike * 5.5)
        else:
            self._energy_avg *= 0.90

        cr.set_line_width(4.5)
        cr.set_line_cap(1)  # cairo.LINE_CAP_ROUND

        for i in range(VISUALIZER_BARS):
            angle = (2 * math.pi * i) / VISUALIZER_BARS - math.pi / 2

            if magnitudes and i < len(magnitudes):
                db = magnitudes[i]
                level = (db - SPECTRUM_THRESHOLD_DB) / (0 - SPECTRUM_THRESHOLD_DB)
                level = max(0.0, min(1.0, level))
                level = level ** 0.4
                level = min(1.0, level * self._bar_gain[i])
            else:
                level = 0.0

            previous = self._visual_levels[i]
            target = level
            if target > previous:
                level = previous + (target - previous) * 0.55
            else:
                level = previous * VISUALIZER_DECAY
            self._visual_levels[i] = level

            level = min(1.0, level + global_boost * 0.7)

            if is_playing and level > 0.05:
                display_level = max(0.0, min(1.0, level + random.uniform(-0.02, 0.03)))
            else:
                display_level = level

            length = VISUALIZER_MIN_LENGTH + display_level * (VISUALIZER_MAX_LENGTH - VISUALIZER_MIN_LENGTH)

            x1 = cx + VISUALIZER_INNER_RADIUS * math.cos(angle)
            y1 = cy + VISUALIZER_INNER_RADIUS * math.sin(angle)
            x2 = cx + (VISUALIZER_INNER_RADIUS + length) * math.cos(angle)
            y2 = cy + (VISUALIZER_INNER_RADIUS + length) * math.sin(angle)

            alpha = 0.45 + 0.55 * display_level
            cr.set_source_rgba(*self._accent_rgba, alpha)
            cr.move_to(x1, y1)
            cr.line_to(x2, y2)
            cr.stroke()

    # --- highlight current track in the list -----------------------------------
    def _highlight_current_row(self):
        if 0 <= self._current_index < len(self._playlist):
            row = self.list_box.get_row_at_index(self._current_index)
            if row is not None:
                self.list_box.select_row(row)

    # --- shared controls -------------------------------------------------
    def _on_play_pause_clicked(self, button):
        if self.local_player.is_playing():
            self.local_player.pause()
            self.play_btn.set_icon_name("media-playback-start-symbolic")
            self.subtitle_label.set_label("Paused")
        elif self._current_index >= 0:
            self.local_player.play()
            self.play_btn.set_icon_name("media-playback-pause-symbolic")
            self.subtitle_label.set_label("Now playing")
        elif self._playlist:
            self._current_index = 0
            self._play_index(0)

    def _on_prev_clicked(self, button):
        if self._current_index > 0:
            self._current_index -= 1
            self._play_index(self._current_index)

    def _on_next_clicked(self, button):
        if self._current_index + 1 < len(self._playlist):
            self._current_index += 1
            self._play_index(self._current_index)

    def _on_volume_changed(self, scale):
        self.local_player.set_volume(scale.get_value() / 100.0)
