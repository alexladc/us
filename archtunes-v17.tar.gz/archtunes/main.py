#!/usr/bin/env python3
"""ArchTunes - player muzical GTK4 cu redare locala si integrare Spotify."""
import sys
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk  # noqa: E402

from archtunes.window import ArchTunesWindow  # noqa: E402


class ArchTunesApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id="com.example.archtunes")
        self.connect("activate", self.on_activate)

    def on_activate(self, app):
        win = self.props.active_window
        if not win:
            win = ArchTunesWindow(application=app)
        win.present()


def main():
    app = ArchTunesApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
